#ifndef FS_TESTS_H
#define FS_TESTS_H

void add_fs_tests(Suite *s);

#endif
